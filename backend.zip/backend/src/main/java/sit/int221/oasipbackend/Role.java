package sit.int221.oasipbackend;

public enum Role {
    admin, lecturer, student
}
